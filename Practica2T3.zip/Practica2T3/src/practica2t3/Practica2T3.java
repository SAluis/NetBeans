/* Salazar Lopez Luis Armando Practica 2  31/10/23 */
/* Calcular el area de un Triangulo */

package practica2t3;
import java.util.Scanner;
public class Practica2T3 {

    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        System.out.println("Ingrese la base del triangulo");
        int Base = Scanner.nextInt();
        System.out.println("Ingrese la altura del triangulo");
        int Altura = Scanner.nextInt();
        double Area = Base * Altura / 2;
        System.out.println("El area del Triangulo es: " +Area);
    } 
}
